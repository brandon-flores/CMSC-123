public class MyIntMul extends MyInt {
  public MyIntMul(int val) {
    super(val);
  }

  @Override
  public int hashCode() {
    // TODO implement multiplication hash
    return super.hashCode();
  }
}

public class MyIntUniv extends MyInt {
  public MyIntUniv(int val) {
    super(val);
  }

  @Override
  public int hashCode() {
    // TODO implement universal hash
    return super.hashCode();
  }
}

# Hash functions and collisions

In this exercise we'll implement different hashing functions, choose different `m` values, and see how this affects the number of collisions.

## Hash methods

- division method - `k mod m`
- multiplication method - `floor(m(kA mod 1))`
- universal method - `[(ak + b) mod p] mod m`

## TODOs

1. implement linear probing in `HashTableLinearProbing.java`
	- be sure to add corresponding tests
2. implement hash functions in `MyIntMul.java` and `MyIntUniv.java`
3. in the test file, create an array of 1000 randomly-generated ints. Try adding these ints to your hash table as `MyInt` values. How many collisions occurred?
4. adjust `m` to try and reduce the number of collisions
5. next, try inserting the ints as `MyIntMul` values, then check collisions. How do the number of collisions compare to previous attempts?
6. finally, try inserting `MyIntUniv` values, then check collisions. How do the number of collisions compare to previous attempts?
7. experiment with different values for `m` to see if this affects the number of collisions.
